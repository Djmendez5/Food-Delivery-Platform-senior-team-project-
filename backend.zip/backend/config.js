module.exports = { REACT_APP_GOOGLE_API_KEY: 'AIzaSyAuQ7gQOcm5Z45J2Nh1xNc7XzR5PjstIAU',
JWT_SECRET: 'qwertyuiopasdfghjklzxcvbnm' 
} 

