const jwt = require('jsonwebtoken');
const {JWT_SECRET} = require('./config.js')

function checkToken(req, res, next) {
	let token = req.headers['authorization'];
	if (token.startsWith("Bearer ")) {
		token = token.slice(7);
	}
	if (!token) {
		res.json("No token.");
	}
	else {
		jwt.verify(token, JWT_SECRET, (err, decoded)=>{
			if (err) {
				res.json("Invalid token.");
			}
			else {
				req.decoded = decoded;
				next();
			}
		})
	}
}

module.exports = checkToken;