const express = require("express");
const Sequelize = require('sequelize');
const app = express();
const port = 7000;
const jwt = require('jsonwebtoken');
const axios = require('axios');
const cors = require('cors');
var bcrypt = require('bcrypt');
const {REACT_APP_GOOGLE_API_KEY, JWT_SECRET} = require('./config.js')
const checkToken = require('./jwtmiddleware.js')
app.use(express.json());
app.use(express.urlencoded());
app.listen(port, () =>{
  console.log("running server on port" + port);
})
const sequelize = new Sequelize('express-mvp-db', 'david', '123', {
  host: 'localhost',
  dialect: 'postgres',
  operatorsAliases:false,
})


const Menus = sequelize.define("Menus", { 
  title: Sequelize.STRING,
  description:Sequelize.STRING,
  nutrition_info:Sequelize.STRING,
  price: Sequelize.INTEGER,
  owner: Sequelize.STRING

})

const Restaurants = sequelize.define("Restaurants", { 
  name: Sequelize.STRING,
  description:Sequelize.STRING,
  email: Sequelize.STRING,
  hours: Sequelize.STRING,
  contact_info: Sequelize.STRING,
  website:Sequelize.STRING,
  address: Sequelize.STRING,
  city:Sequelize.STRING
})

const Order = sequelize.define("Order", {
  name: Sequelize.STRING,
  item:Sequelize.STRING,
  price:Sequelize.INTEGER,
  quantity: Sequelize.INTEGER,
  email: Sequelize.STRING,
  maker:Sequelize.STRING

})

const AccountList = sequelize.define("AccoutList", {
        firstname: Sequelize.STRING,
        lastname:Sequelize.STRING,
        username:Sequelize.STRING,
        phone: Sequelize.STRING,
        email: Sequelize.STRING,
        password: Sequelize.STRING,
        address: Sequelize.STRING
      
      })


      sequelize.sync({
        logging: console.log,
        force: true
      })
      .then(() =>{
       
      })
      .then(() => {
        console.log("Success!");
      })
      .catch(err => {
        console.error("not sucess");
      });
      //app.get('/',(req,res)=>{
      app.get('/', (req,res) =>{
        
        res.send("Hello")
      });

      
    app.post('/getmenuinfo',checkToken,(req,res)=>{
      Menus.findAll({
        where:{
          owner: req.body.email
        }
      }).then(user =>{
        res.json(user);
      })

    })

    app.get('/Accountinfo',(req,res)=> {
      AccountList.findAll()
      .then(user => {
        res.json(user);
      })
    })

    app.post('/additem',checkToken, (req,res) =>{ 
      if (!req.body.owner.includes("@") || !req.body.owner.includes(".") ) { 
        res.status(400).send("Email is not valid");
        return; 
    }
      Menus.create({
        title: req.body.title,
        description: req.body.description,
        nutrition_info:req.body. nutrition_info,
        price: req.body.price,
        owner: req.body.owner 
      })
      res.send("item has been added");
    })

      app.put('/editprofile', checkToken, (req,res)=>{
        const user =  AccountList.update({
            firstname: req.body.firstname,
            lastname:req.body.lastname,
            username:req.body.username,
            phone: req.body.phone,
            password: req.body.password,
            address: req.body.address,
          email : req.body.email},
         {where: {email :req.body.email}}).then(rows=>{res.json(rows);
        })
        if (!user) {
          res.send("User not found.");
        }
      })

      app.delete('/removeaccount',checkToken, (req, res)=>{
        AccountList.destroy({ 
          where: {email : req.body.email}
      }).then(()=>{
        res.send("deleted")
      })
    })
        
    app.put('/deleteaccount', (req,res)=>{
      AccountList.update({
        item : ""},
       {where: {name :req.body.name}}).then(rows=>{res.json(rows);
      })
    })

      app.get('/AccountList', (req,res)=>{
      res.send("creating lists and items ")
  
      })

      app.post('/signup', async (req, res) => {
            const firstname= req.body.firstname;
            const lastname= req.body.lastname;
            const username= req.body.username;
            const phone= req.body.phone;
            const email= req.body.email;
            const password= req.body.password;
            const address= req.body.address;
            const saltRounds = 10;
        if (!req.body.email.includes('@') || !req.body.email.includes('.')) {
          res.status(400).send('Email is not valid');
          return;
        }
        try {
          bcrypt.hash(password, saltRounds, function (err, hash) {
          const newuser =  AccountList.create({
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            username: req.body.username,
            phone: req.body.phone,
            email: req.body.email,
            password: hash,
            address: req.body.address
          });
          const token = jwt.sign({
            //firstname: newuser.firstname,
            //lastname: newuser.lastname,
            username:newuser.username,
            password:newuser.password
            //email: newuser.email
          }, JWT_SECRET);
          res.send({
            isLoggedIn: true,
            token: token
          });
        });
        } catch (err) {
          console.log(err);
        }
      
      });


      app.post('/login', async (req, res)=>{
        const { username, password } = req.body;
        console.log("User submitted: ", username, password);
        const user = await AccountList.findOne({
          where: {
            username: req.body.username,
            //password: req.body.password
          }

        })
        if (!user) {
          res.send("User not found.");
        }
        else {
          bcrypt.compare(password, user.password, function (err, result) {
          if(result ===true){
            const token = jwt.sign({
            username:user.username,
            password:user.password
            //firstname: user.firstname,
            //lastname: user.lastname,
            //email: user.email
           }, JWT_SECRET);
          res.send({
            isLoggedIn: true,
            token: token
          });
            }
            });
          }
      })

      app.post('/getorderhistory',checkToken, (req,res)=>{
        Order.findAll({
          where:{
            email: req.body.email
          }
        }).then(user =>{
          res.json(user);
        })
  
      })

      app.post('/addOrder', checkToken, (req,res) =>{
        if (!req.body.email.includes("@")|| !req.body.email.includes(".")) { 
          res.status(400).send("Email is not valid");
          return; 
      }   
       Order.create({
          name: req.body.name,
          item: req.body.item,
          price:req.body.price,
          quantity:req.body.quantity,
          email:req.body.email,
          maker: req.body.maker
        })
        res.send("order has been added");
      })
      
      app.post('/addRestaurant', checkToken,(req,res) =>{
        if (!req.body.email.includes("@")|| !req.body.email.includes(".")) { 
          res.status(400).send("Email is not valid");
          return; 
      }   
        Restaurants.create({
          name: req.body.name,
          description: req.body.description,
          email:req.body.email,
          hours:req.body.hours,
          contact_info: req.body.contact_info,
          website: req.body.website,
          address:req.body.address,
          city:req.body.city
        })
        res.send("Restaurant has been added");
      })
      
      app.post('/getrestaurants',checkToken,(req,res)=>{
        Restaurants.findAll({
          where:{
            city: req.body.city
          }
        }).then(user =>{
          res.json(user);
        })
  
      })
      sequelize.sync({
        logging: console.log,
        force: true
      })
      .then(() =>{
       
      })
      .then(() => {
        console.log("Success!");
      })
      .catch(err => {
        console.error("not sucess");
      });
      app.post('/getUserLocation', (req, res) =>{
        console.log(REACT_APP_GOOGLE_API_KEY)
          axios.post(`https://www.googleapis.com/geolocation/v1/geolocate?key=${REACT_APP_GOOGLE_API_KEY}`, {
      headers: {
        "Content-Type": "application/json"
      },

    })
      .then(response => res.json(response.data.location))
      .catch(err => console.log('error', err))
      })

