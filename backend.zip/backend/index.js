const express = require("express");
const Sequelize = require('sequelize');
const app = express();
const port = 7000;
const jwt = require('jsonwebtoken');
const axios = require('axios');
const cors = require('cors');
var bcrypt = require('bcrypt');
const {REACT_APP_GOOGLE_API_KEY, JWT_SECRET} = require('./config.js')
const checkToken = require('./jwtmiddleware.js')
const nodemailer = require('nodemailer') ;
app.use(express.json());
app.use(express.urlencoded());
app.listen(port, () =>{
  console.log("running server on port" + port);
})
const sequelize = new Sequelize('express-mvp-db', 'david', '123', {
  host: 'localhost',
  dialect: 'postgres',
  operatorsAliases:false,
})

const Profit = sequelize.define("Profit", {
item: Sequelize.STRING,
email:Sequelize.STRING,
profit: Sequelize.INTEGER
})
const Menus = sequelize.define("Menus", { 
  item: Sequelize.STRING,
  description:Sequelize.STRING,
  nutrition_info:Sequelize.STRING,
  price: Sequelize.INTEGER,
  cost:Sequelize.INTEGER,
  owner: Sequelize.STRING,
  review: Sequelize.FLOAT,
  picture: Sequelize.STRING

})

const Reviews = sequelize.define("Review", { 
  item: Sequelize.STRING,
  customer:Sequelize.STRING,
  customer_review:Sequelize.INTEGER
  
})


const Restaurants = sequelize.define("Restaurants", { 
  license: Sequelize.INTEGER,
  name: Sequelize.STRING,
  description:Sequelize.STRING,
  email: Sequelize.STRING,
  hours: Sequelize.STRING,
  contact_info: Sequelize.STRING,
  website:Sequelize.STRING,
  address: Sequelize.STRING,
  city:Sequelize.STRING
})

const Order = sequelize.define("Order", {
  name: Sequelize.STRING,
  item:Sequelize.STRING,
  price:Sequelize.INTEGER,
  quantity: Sequelize.INTEGER,
  email: Sequelize.STRING,
  maker:Sequelize.STRING

})

const AccountList = sequelize.define("AccoutList", {
        firstname: Sequelize.STRING,
        lastname:Sequelize.STRING,
        username:Sequelize.STRING,
        phone: Sequelize.STRING,
        email: Sequelize.STRING,
        password: Sequelize.STRING,
        address: Sequelize.STRING,
        isRestaurant: Sequelize.BOOLEAN
      
      })


      sequelize.sync({
        logging: console.log,
        force: true
      })
      .then(() =>{
       
      })
      .then(() => {
        console.log("Success!");
      })
      .catch(err => {
        console.error("not sucess");
      });
      //app.get('/',(req,res)=>{
      app.get('/', (req,res) =>{
        
        res.send("Hello")
      });


    app.post('/getprofits',checkToken,(req,res)=>{
      Profit.findAll({
        where:{
          email:req.body.email
        }
      }).then(profits =>{
        res.json(profits)
      })
    })
      
    app.post('/getmenuinfo',checkToken,(req,res)=>{
      Menus.findAll({
        where:{
          owner: req.body.email
        }
      }).then(user =>{
        res.json(user);
      })

    })

    app.post('/Accountinfo',async (req,res)=> {
      const username = req.body.username;
        //console.log("User submitted: ", username, password);
        const user = await AccountList.findOne({
          where: {
            username: req.body.username,
          }
        })
        if (!user) {
          res.send("User not found.");
        }
        else {
          res.send({
            user
          });
    }
    })

    app.post('/additem',checkToken, (req,res) =>{ 
      if (!req.body.owner.includes("@") || !req.body.owner.includes(".") ) { 
        res.status(400).send("Email is not valid");
        return; 
    }
      Menus.create({
        item: req.body.item,
        description: req.body.description,
        nutrition_info:req.body.nutrition_info,
        cost:req.body.cost,
        price: req.body.price,
        owner: req.body.owner,
        picture:req.body.picture
      })
      res.send("item has been added");
    })

    app.put('/isRestaurant', checkToken, (req,res)=>{
      const user =  AccountList.update({
         isRestaurant:true},
       {where: {username :req.body.username}}).then(rows=>{res.json(rows);
      })
    })


    
      app.put('/editprofile', checkToken, (req,res)=>{
        const user =  AccountList.update({
            firstname: req.body.firstname,
            lastname:req.body.lastname,
            username:req.body.username,
            phone: req.body.phone,
            password: req.body.password,
            address: req.body.address,
          email : req.body.email},
         {where: {email :req.body.email}}).then(rows=>{res.json(rows);
        })
        if (!user) {
          res.send("User not found.");
        }
      })

      app.delete('/removeaccount',checkToken, (req, res)=>{
        AccountList.destroy({ 
          where: {email : req.body.email}
      }).then(()=>{
        res.send("deleted")
      })
    })
        
    app.put('/deleteaccount', (req,res)=>{
      AccountList.update({
        item : ""},
       {where: {name :req.body.name}}).then(rows=>{res.json(rows);
      })
    })

      app.get('/AccountList', (req,res)=>{
      res.send("creating lists and items ")
  
      })

      app.post('/signup', async (req, res) => {
            const firstname= req.body.firstname;
            const lastname= req.body.lastname;
            const username= req.body.username;
            const phone= req.body.phone;
            const email= req.body.email;
            const password= req.body.password;
            const address= req.body.address;
            
            const saltRounds = 10;
        if (!req.body.email.includes('@') || !req.body.email.includes('.')) {
          res.status(400).send('Email is not valid');
          return;
        }
        try {
          bcrypt.hash(password, saltRounds, function (err, hash) {
          const newuser =  AccountList.create({
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            username: req.body.username,
            phone: req.body.phone,
            email: req.body.email,
            password: hash,
            address: req.body.address,
            isRestaurant: false
          });
          const token = jwt.sign({
            username:newuser.username,
            password:newuser.password
          }, JWT_SECRET);
          res.send({
            isLoggedIn: true,
            token: token
          });
        });
        } catch (err) {
          console.log(err);
        }
      
      });
      app.put('/addPicture',checkToken, (req,res)=>{
        const pic = Menus.update({
          picture: req.body.picture
        }, 
        {where: {item :req.body.item}}).then(rows=>{res.json(rows);
        })
      })
      
      

      app.put('/updateRating',checkToken, (req,res)=>{
        const rate = Menus.update({
          review: req.body.review
        }, 
        {where: {item :req.body.item}}).then(rows=>{res.json(rows);
        })
      })
      app.post('/getPicture',checkToken, async(req,res)=>{
        const pic = await Menus.findOne({
          where:{
          item:req.body.item,
          }
        })
        if (!pic) {
          res.send("item not found.");
        }
        else{
          res.send(item);
          }
      })
      app.post('/getreview',checkToken, async (req,res)=>{
        const item = await Reviews.findAll({
          where: {
            item: req.body.item,
          }
        })
        if (!item) {
          res.send("item not found.");
        }
        else{
        res.send(item);
        }
      })

      app.post('/review',checkToken, async (req,res)=>{
        const item = await Menus.findOne({
          where: {
            item: req.body.item,
          }
        })
        if (!item) {
          res.send("item not found.");
          
        }
        else{
        const review =Reviews.create({
          item: req.body.item,
          customer: req.body.customer,
          customer_review: req.body.customer_review,
          
        }).then(item =>{
          res.json(item);
        })
        }
      })

      
      app.post('/login', async (req, res)=>{
        const { username, password } = req.body;
        console.log("User submitted: ", username, password);
        const user = await AccountList.findOne({
          where: {
            username: req.body.username,
          }

        })
        if (!user) {
          res.send("User not found.");
        }
        else {
          bcrypt.compare(password, user.password, function (err, result) {
          if(result ===true){
            const token = jwt.sign({
            username:user.username,
            password:user.password
           }, JWT_SECRET);
          res.send({
            isLoggedIn: true,
            token: token
          });
            }
            });
          }
          
      })
      

      app.post('/getorderhistory',checkToken, (req,res)=>{
        Order.findAll({
          where:{
            email: req.body.email
          }
        }).then(user =>{
          res.json(user);
        })
      })
      
      

      app.post('/addOrder', checkToken, (req,res) =>{
        if (!req.body.email.includes("@")|| !req.body.email.includes(".")) { 
          res.status(400).send("Email is not valid");
          return; 
      }
      
      const output=
      `<p>You have a new order request</p>
      <h3>Order details</h3>
      <ul>
        <i>Customer: ${req.body.name}</i>
        </br>
        <i>Dish: ${req.body.item}</i>
        </br>
        <i>quantity: ${req.body.quantity}</i>
        </br>
        <i>price per item: ${req.body.price}</i>
        </br>
        <i>Custumer email: ${req.body.email}</i>
      </ul>`
      ;
      
      var smtpTransport = nodemailer.createTransport({
        service: "Gmail",
        auth: {
            user: "fooddeliveryplatform@gmail.com",
            pass: "FoodDeliveryCs490"
        },
        tls:{
          rejectUnauthorized:false
        }
    });
    
    var mailOptions = {
      from: 'fooddeliveryplatform@gmail.com',
      to: req.body.maker, 
      subject: ' You have a new food order from ' + req.body.email,
      html:output
  }
  smtpTransport.sendMail(mailOptions, function(error, response){
    if(error){
        console.log(error);
    }else{
        res.redirect('/');
    }
});
      
       Order.create({
          name: req.body.name,
          item: req.body.item,
          price:req.body.price,
          quantity:req.body.quantity,
          email:req.body.email,
          maker: req.body.maker
        })
        res.send("order has been added");
      })



      app.post("/profit",checkToken,(req,res) => {
       Profit.create({
        item: req.body.item,
        email: req.body.email,
        profit: req.body.profit
       })
       res.send("plus")
        })
      app.post('/addRestaurant', checkToken,(req,res) =>{
        if (!req.body.email.includes("@")|| !req.body.email.includes(".")) { 
          res.status(400).send("Email is not valid");
          return; 
      }   
        Restaurants.create({
          license:req.body.license,
          name: req.body.name,
          description: req.body.description,
          email:req.body.email,
          hours:req.body.hours,
          contact_info: req.body.contact_info,
          website: req.body.website,
          address:req.body.address,
          city:req.body.city
        })
        res.send("Restaurant has been added");
      })
      app.post("/getCostPrice",checkToken, async (req,res)=>{
        const info =  await Menus.findOne({
          where: {
            item: req.body.item,
          }
        })
        res.send({
          info
        });

      })
      app.post('/getrestaurants',checkToken,(req,res)=>{
        Restaurants.findAll({
          where:{
            city: req.body.city
          }
        }).then(user =>{
          res.json(user);
        })
  
      })
      sequelize.sync({
        logging: console.log,
        force: true
      })
      .then(() =>{
       
      })
      .then(() => {
        console.log("Success!");
      })
      .catch(err => {
        console.error("not sucess");
      });
      app.post('/getUserLocation', (req, res) =>{
        console.log(REACT_APP_GOOGLE_API_KEY)
          axios.post(`https://www.googleapis.com/geolocation/v1/geolocate?key=${REACT_APP_GOOGLE_API_KEY}`, {
      headers: {
        "Content-Type": "application/json"
      },

    })
      .then(response => res.json(response.data.location))
      .catch(err => console.log('error', err))
      })

      app.post('/getAddress', (req, res) => {
        const lat=req.body.lat
        const lng=req.body.lng
        console.log(req.body)
        axios.post(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${REACT_APP_GOOGLE_API_KEY}`, {
          headers: {
            "Content-Type": "application/json"
          },
        })
        .then(response=>res.json(response.data))
      })